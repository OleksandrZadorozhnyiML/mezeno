# Generated from create_mezen.Rmd: do not edit by hand

#' this is an alternative function to search in the titles of the given datasets and return the value of the dataset found in the list
#' 
#' @param string text to look for 
#' @param text data which is to be searched
#' @export 
#' 
#' 
#' 
check_string_in_text <- function(string, text) {
  # Ensure inputs are characters
  if (!is.character(string) || !is.character(text)) {
    stop("Both inputs must be character strings.")
  }
  
  # Use grepl to check for the presence of the string in the text
  result <- grepl(pattern = string, x = text, fixed = TRUE)
  
  return(result)
}
