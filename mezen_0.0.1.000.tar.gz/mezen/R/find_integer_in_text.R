# Generated from create_mezen.Rmd: do not edit by hand

#' Question to the LLM
#' 
#' @param text parameter that sets the input text for LLM to retrieve from
#' 
#' @export 
#' 
find_integer_in_text <-function(text) {
  # Use regular expression to match integer numbers in the text
  match <- regmatches(text, regexpr("\\b\\d+\\b", text))
  
  # Check if a match was found
  if (length(match) > 0) {
    return(match)
  } else {
    return(NULL)  # Return NULL if no integer was found
  }
}
