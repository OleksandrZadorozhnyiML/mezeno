# Generated from create_mezen.Rmd: do not edit by hand

#' this is an alternative function to search in the titles of the given datasets and return the value of the dataset found in the list
#' 
#' @param search_text parameter that sets the input text 
#' @param file parameter that sets the file to read the json data from
#' @export 
#' 
#' 
#' 
parse_data <-function(search_text,file){
  df=fromJSON(file)
  n = length(df)
  for (i in 1:n){
    flag = check_string_in_text(search_text,df[[i]]$title)
    if (flag) {
      return(i)
    }
  }
  if (!(flag)) {
    return(0)
  }
}

