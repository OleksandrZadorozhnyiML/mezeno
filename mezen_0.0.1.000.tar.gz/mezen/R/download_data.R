# Generated from create_mezen.Rmd: do not edit by hand

#' Question to the LLM
#' 
#' @param question_text parameter that sets the input text 
#' 
#' @export 
#' 
download_data <- function(search_text,file){
  element = parse_data(search_text,file)
  df=fromJSON(file)
  # finding the zenodo doi which is then be transformed to an integer to download a record from
  link = df[[element]]$zenododoi
  # downloading the record contained in the link
  
  if (!dir.exists("./download_zenodo")) 
    {
        dir.create("download_zenodo")
    }
  #download files with shortcut function 'download_zenodo'
  download_zenodo(path = "download_zenodo", link,timeout = 180)
  downloaded_files <- list.files("download_zenodo")
  
  
  message <- paste("Dataset successfully downloaded to /download_zenodo")
  print(message)
}
